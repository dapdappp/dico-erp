<div class="page-heading"><div><h1>Pengajuan Cuti</h1><p>Pantau permohonan cuti karyawan.</p></div></div>
<div class="panel table-panel">
    <div class="table-heading"><h2>Daftar Pengajuan</h2><span class="muted">Data contoh</span></div>
    <div class="table-wrap">
        <table>
            <thead><tr><th>Nama</th><th>Jenis Cuti</th><th>Tanggal</th><th>Alasan</th><th>Status</th></tr></thead>
            <tbody>
                <tr><td>Andi Pratama</td><td>Tahunan</td><td>12–14 Okt 2026</td><td>Keperluan keluarga</td><td><span class="tag tag-orange">Menunggu</span></td></tr>
                <tr><td>Siti Aminah</td><td>Sakit</td><td>8 Okt 2026</td><td>Pemulihan kesehatan</td><td><span class="tag tag-green">Disetujui</span></td></tr>
                <tr><td>Budi Santoso</td><td>Tahunan</td><td>20–21 Okt 2026</td><td>Keperluan pribadi</td><td><span class="tag tag-red">Ditolak</span></td></tr>
            </tbody>
        </table>
    </div>
</div>
