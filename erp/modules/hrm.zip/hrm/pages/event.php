<div class="page-heading"><div><h1>Data Event</h1><p>Daftar kegiatan dan acara internal.</p></div><button class="primary-button" id="showEventMessage">+ Buat Event</button></div>
<div class="event-grid">
    <article class="panel event-card"><span class="event-date">15 OKT 2026</span><h2>Pelatihan Komunikasi</h2><p>Pelatihan internal untuk meningkatkan komunikasi tim.</p><span class="tag tag-blue">Akan datang</span></article>
    <article class="panel event-card"><span class="event-date">22 OKT 2026</span><h2>Town Hall DICO</h2><p>Pertemuan bulanan dan pembaruan perusahaan.</p><span class="tag tag-blue">Akan datang</span></article>
</div>
<p class="help-text" id="eventMessage" role="status"></p>
