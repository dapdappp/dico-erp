<div class="page-heading">
    <div>
        <h1>Dashboard HRM</h1>
        <p>Ringkasan sederhana untuk mengelola informasi SDM.</p>
    </div>
    <span class="status-pill">Mode percobaan</span>
</div>

<div class="stats-grid">
    <article class="stat-card">
        <div class="stat-icon blue">K</div>
        <p>Total Karyawan</p>
        <h2>12</h2>
        <small>Data contoh</small>
    </article>
    <article class="stat-card">
        <div class="stat-icon orange">C</div>
        <p>Pengajuan Cuti</p>
        <h2>3</h2>
        <small>Data contoh</small>
    </article>
    <article class="stat-card">
        <div class="stat-icon purple">E</div>
        <p>Event Aktif</p>
        <h2>2</h2>
        <small>Data contoh</small>
    </article>
    <article class="stat-card">
        <div class="stat-icon green">R</div>
        <p>Registrasi Peserta</p>
        <h2>8</h2>
        <small>Data contoh</small>
    </article>
</div>

<div class="panel welcome-panel">
    <div>
        <span class="eyebrow">SELAMAT DATANG</span>
        <h2>Modul HRM DICO</h2>
        <p>Gunakan menu di sebelah kiri untuk mencoba halaman karyawan, cuti, event, dan registrasi.</p>
    </div>
    <div class="welcome-illustration" aria-hidden="true">HR</div>
</div>
